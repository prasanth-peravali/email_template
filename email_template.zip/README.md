1. Extract the folder to htdocs
2. import sql file to mysql
3. provide db and mailtrap details in .env file
4. run composer update

5. 	URL : 
	http://localhost/email_template/public/api/send-mail
	parameters: 
	{
	    "template_id":1,
	    "to":"test@test.com"
	}

